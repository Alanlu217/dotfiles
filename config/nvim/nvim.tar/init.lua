require("core").start()
