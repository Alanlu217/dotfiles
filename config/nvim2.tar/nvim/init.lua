-- Leader
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- Order matters: plugins that others depend on come first
for _, mod in ipairs({
  "options",

  -- Plugins (lua/plugins/*.lua), one file per plugin
  "plugins.gitsigns",
  "plugins.catppuccin",
  "plugins.mini-pick",
  "plugins.mini-extra", -- needs mini.pick
  "plugins.mini-files",
  "plugins.mini-clue",
  "plugins.lspconfig",
  "plugins.blink-lib",  -- needed by the other blink.* plugins
  "plugins.blink-cmp",
  "plugins.blink-pairs",
  "plugins.blink-indent",

  -- Core config
  "lsp",
  "format",
  "statusline",
  "terminal",
  "keymaps",
}) do
  require(mod)
end
