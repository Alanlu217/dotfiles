local map = vim.keymap.set

-- Reload: clear cached modules that live in this config, then re-run init.lua
map("n", "<leader>R", function()
  local lua_dir = vim.fn.stdpath("config") .. "/lua/"
  for name in pairs(package.loaded) do
    local rel = name:gsub("%.", "/")
    if vim.uv.fs_stat(lua_dir .. rel .. ".lua") or vim.uv.fs_stat(lua_dir .. rel .. "/init.lua") then
      package.loaded[name] = nil
    end
  end
  dofile(vim.env.MYVIMRC)
  vim.notify("Config reloaded")
end, { desc = "Reload config" })

map("n", "<C-a>", "ggVG", { desc = "Select whole file" })

-- System clipboard
map({ "n", "v" }, "<leader>y", [["+y]], { desc = "Yank to system clipboard" })
map("n", "<leader>Y", [["+Y]], { desc = "Yank line to system clipboard" })
map({ "n", "v" }, "<leader>p", [["+p]], { desc = "Paste from system clipboard" })
map({ "n", "v" }, "<leader>P", [["+P]], { desc = "Paste before from system clipboard" })

-- Window navigation: Alt+hjkl / Alt+arrows, from normal or terminal mode
local arrows = { h = "Left", j = "Down", k = "Up", l = "Right" }
for dir, arrow in pairs(arrows) do
  for _, key in ipairs({ dir, arrow }) do
    map({ "n", "i", "t" }, "<A-" .. key .. ">", "<C-\\><C-n><C-w>" .. dir, { desc = "Window " .. dir })
  end
end

-- Clear highlighting on escape
map("n", "<Esc>", "<cmd>nohlsearch<CR>", { desc = "Clear search highlight" })
