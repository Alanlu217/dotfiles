vim.pack.add { "https://github.com/lewis6991/gitsigns.nvim" }
